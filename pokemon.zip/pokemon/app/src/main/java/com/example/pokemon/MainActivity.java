package com.example.pokemon;

import androidx.annotation.ArrayRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.AbsListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<pokemon> ball = new ArrayList<>();

     pokemon p1= new pokemon("bulbasaur",R.drawable.bulbasaur, 200,600,100);
     pokemon p2= new pokemon("charmander",R.drawable.charmander, 200,600,100);
     pokemon p3= new pokemon("venusaur",R.drawable.venusaur, 200,600,100);

     ball.add(p1);
     ball.add(p2);
     ball.add(p3);

        RecyclerView D =findViewById(R.id.cw7);
    }


}