package com.example.pokemon;

public class pokemon {
    public pokemon(String bulbasaur, int bulbasaur1, int i, int i1, int i2) {
    }
}
