public class pokemon {
    public pokemon(String name, int image, int attack, int defance, int totAL) {
        this.name = name;
        this.image = image;
        this.attack = attack;
        this.defance = defance;
        this.totAL = totAL;
    }

    String name ;
    int image ;
    int attack ;
    int defance ;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefance() {
        return defance;
    }

    public void setDefance(int defance) {
        this.defance = defance;
    }

    public int getTotAL() {
        return totAL;
    }

    public void setTotAL(int totAL) {
        this.totAL = totAL;
    }

    int totAL ;
}
